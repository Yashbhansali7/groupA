import 'package:flutter/material.dart';
class EventScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text('Hello! Welcome to Events Screen'),
      ),
    );
  }
}