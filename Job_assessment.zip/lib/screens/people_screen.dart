import 'package:flutter/material.dart';
class PeopleScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    
    return Scaffold(
      body: Center(
        child: Text('Hello! Welcome to People\'s Screen'),
      ),
    );
  }
}