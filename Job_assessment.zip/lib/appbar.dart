import 'package:flutter/material.dart';
class CustomAppbar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Row(        
        children: [
          IconButton(onPressed: (){},splashRadius: 20, icon: Icon(Icons.menu_outlined,size: 30,color: Colors.teal[300],)),
          IconButton(onPressed: (){},splashRadius: 20, icon: Icon(Icons.notifications_none_outlined,size: 30,color: Colors.teal[300],)),
          IconButton(onPressed: (){},splashRadius: 20, icon: Icon(Icons.search_outlined,size: 30,color: Colors.teal[300],)),
          SizedBox(width: 79,),
          TextButton.icon(onPressed: (){}, icon: Icon(Icons.star_border_outlined,size: 30,color: Colors.teal[300],),label: Text('11', style: TextStyle(color: Colors.teal[300],)),),
          TextButton.icon(onPressed: (){}, icon: Icon(Icons.wallet_travel_outlined,size: 30,color: Colors.teal[300],), label: Text('1900', style: TextStyle(color: Colors.teal[300],),),),
        ],
      ),
    );
  }
}