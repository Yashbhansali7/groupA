import './models/post_model.dart';

List<Post> LOCAL_DATA = [
  Post(
      'https://funkylife.in/wp-content/uploads/2021/06/whatsapp-dp-pic-8-scaled.jpg',
      '10 Benefits of Meeting People Online',
      'Pooja Bhatia',
      'https://previews.123rf.com/images/wavebreakmediamicro/wavebreakmediamicro1603/wavebreakmediamicro160320984/54308373-family-clicking-selfies-while-sitting-on-sofa-at-home.jpg',
      645,
      52,
      'The quick brown fox jumped over the lazy dog'),
  Post(
      'https://images-na.ssl-images-amazon.com/images/I/6162Ih5B4GL._SL1500_.jpg',
      'Disney characters we all love to see',
      'Vaibhav Singh',
      'https://assets-news-bcdn.dailyhunt.in/cmd/resize/400x400_80/fetchdata16/images/a3/80/68/a38068a0679377a609234e719a13f5f6eddebb0af4ac3a53fc2410c33c7a75f9.jpg',
      133,
      12,
      'The starting of the week doing work'),
  
];
List<Post> GLOBAL_DATA = [
   Post(
      'https://images.financialexpress.com/2021/01/vaio-laptop.jpg',
      'How to download a movie online',
      'Vishnu Kumar',
      'https://www.facetuneapp.com/wp-content/uploads/2021/01/group-selfie-pose-tips-1200x799.jpg',
      2345,
      320,
      'Currently Downloading a Movie Online'),
];
