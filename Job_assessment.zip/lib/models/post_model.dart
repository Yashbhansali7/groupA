class Post {
  final String profilePhoto;
  final String postName;
  final String userName;
  final String postImage;
   int likeNumber;
   int commentNumber;
  final String caption;
   Post(
      this.profilePhoto,
      this.postName,
      this.userName,
      this.postImage,
      this.likeNumber,
      this.commentNumber,
      this.caption,
      );
  
}
