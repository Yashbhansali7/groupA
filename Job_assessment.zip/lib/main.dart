import 'package:flutter/material.dart';

import './screens/swipe_screen.dart';
import './screens/tabs_screen.dart';
void main() {
  runApp(MyApp());
}
class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
        title: 'Job Assessment',
        theme: ThemeData(
          primarySwatch: Colors.teal,
        ),
        routes: {
          '/': (ctx) => TabsScreen(),
         SwipeScreen.routeName: (ctx) => SwipeScreen()
        });
  }
}
